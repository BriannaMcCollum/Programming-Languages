//Brianna McCollum
#include <Python.h>
#include <iostream>
//added for reading files
#include <fstream>
#include <Windows.h>
#include <cmath>
#include <string>

using namespace std;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}

/*
Description:
	reads in the choice from the user and returns that choice if it falls inside the proper threshold
Example:
	int x = getMenuChoice(4);
Return:
	return either 1,2,3 or 4
*/
unsigned int getMenuChoice(unsigned int maxChoice) {
	int c;
	cin >> c;
	bool go = true;

	//Will not exit until c is within the range of maxChoice
	while (go) {
		if (c <= maxChoice && c > 0) {
			//returns in the while loop, no else needed since this exits the function
			return c;
		}
		cin >> c;
	}
}


//Returns a string of length n, each character a c.
string nCharString(size_t n, char c) {
	//initialize the string
	string final = "";

	//for loop for the length specificed
	for (int i = 0; i < n; i++) {
		final += c;
	}

	return final;
}

//Prints the instructions menu. Condensed to a function for ease of use
void printMenu() {
	cout << nCharString(50, '=') << endl;
	cout << "Welcome to Corner Grocer's Data Analysis program!" << endl;
	cout << nCharString(50, '=') << endl;
	cout << "Option 1 - List of items with amount purchased" << endl;
	cout << "Option 2 - Enter an item and recieve the times purchased" << endl;
	cout << "Option 3 - Display a histogram for item purchase frequencies" << endl;
	cout << "Option 4 - Quit program" << endl;
	cout << nCharString(50, '=') << endl;
}


/*
Description:
	reads the given file and creates a purchase frequency histogram from it, automatically printing it to console
Example:
	readFileHistogram("frequency.dat");
Output:
	Yams *****
	Beets ***
	Broccoli **
	etc...
*/
void readFileHistogram(string doc) {
	//Input file stream
	ifstream inFS;
	string line;
	int value;

	inFS.open(doc);
	//stop the function if the file can't be opened
	if (!inFS.is_open()) {
		cout << "Could not open file " << doc << endl;
		return;
	}

	//continue reading until the end is hit
	while (inFS) {
		// Read a Line from File
		getline(inFS, line);

		//the last line is an empty line, so that's our signal to leave the loop
		if (line == "") {
			//close file
			inFS.close();
			return;
		}

		//get necessary information from line
		value = stoi(&line.back());
		//if the value is 0, then it must be a number like 10 or 20, since it's impossible to have 0 frequency at this point
		if (value == 0) {
			value = stoi(line.substr(line.length() - 2));
			//adjust line appropriately to the extra removed char
			line = line.substr(0, line.size() - 3);
		}
		else {
			//normal amount to remove for a singular digit frequency
			line = line.substr(0, line.size() - 2);
		}
	
		//format to a histogram and output
		cout << line << " " << nCharString(value, '*') << endl;
	}

	//just in case we somehow get out of the while loop without hitting a blank line
	inFS.close();
}


void main()
{
	//initialize variables
	bool go = true;
	int choice;
	int frequency;
	string product;

	//print menu
	printMenu();
	//Can only choose 1, 2, 3 or 4
	choice = getMenuChoice(4);

	while (go) {
		switch (choice) {
		//list of items with number times purchased
		case 1:
			CallProcedure("option1");
			break;
		//return a number representing how many times a specific item was purchased in a given day
		case 2:
			cout << "What item are you looking for? (Case Sensitive)" << endl;
			cin >> product;

			//send desired product to python
			frequency = callIntFunc("option2", product);
			cout << product << " frequency: " << frequency << endl;
			break;
		// text-based histogram listing all items purchased in a given day
		//along with a representation of the number of times each item was purchased
		case 3:
			//creates frequency.dat and fills it with data in Python
			CallProcedure("option3");

			//reads the data Python wrote to the new created file
			readFileHistogram("frequency.dat");

			break;
		//end the program
		case 4:
			go = false;
			break;
		default:
			cout << "Error: Somehow got default even after the choice validation. Amazing." << endl;
			go = false;
			break;
		}
		//If we're still looping, get user input again
		if (go) {
			choice = getMenuChoice(4);
		}
	}

	cout << "Thank you, and have a nice day!" << endl;
}