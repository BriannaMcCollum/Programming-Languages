import re
import string

#Global variable for the list of grocery items and dictionary that includes frequency
itemList = []
itemDict = {}

def printsomething():
    print("Hello from python!")

def PrintMe(v):
    print("You sent me: " + v)
    return 100;

def SquareValue(v):
    return v * v

#internal Python function to read txt document and store the information
def ReadDocument(doc):
    file1 = open(doc, "r")

    #reads the information from the txt document
    data =  file1.read()

    #splits that data into a list to use for calculations
    #Then stores that data in the itemList
    tempList = data.replace('\n', ' ').split(" ")
    for item in tempList:
        itemList.append(item)

    #print(doc + " has been read!")
    file1.close()

#internal Python function to calculate the frequency of items and store it in the dictionary
def CountFrequency():
    #If the item list is empty, read from the document
    if len(itemList) == 0:
        ReadDocument("CS210_Project_Three_Input_File.txt")

    #adds the values to the dictionary, including their frequency as the value under the key item
    for i in itemList:
        if i not in itemDict:
            itemDict[i] = 1
        else:
            itemDict[i] = itemDict[i] + 1

def option1():
    CountFrequency()

    #properly formats the output for option 1
    for i in itemDict:
        print("{}, {}".format(i, itemDict[i]))

def option2(v):
    CountFrequency()
    #frequency will default to 0 if object is not found
    frequency = 0
    #search for desired value in dictionary
    for i in itemDict:
        if i == v:
            frequency = itemDict[i]

    return frequency;

def option3():
    CountFrequency()

    #create the new output file to hold the data
    outputFile = open("frequency.dat", "w")

    #writes information from the dictionary to the new frequency.dat file
    for i in itemDict:
        outputFile.write("{} {}\n".format(i, itemDict[i]))